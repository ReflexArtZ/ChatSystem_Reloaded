package de.emeraldmc.chatsystem;

public enum ChatIssue {
    CAPS, SPAM, TIME, AD;
}
